﻿CREATE DATABASE QuanLyTrgMamNon;
USE QuanLyTrgMamNon;

CREATE TABLE PhuHuynh (
	MaPhuHuynh VARCHAR(20) PRIMARY KEY,
    TenPH NVARCHAR(100),
    Sdt VARCHAR(15),
    GioiTinh NVARCHAR(10) NOT NULL CHECK (GioiTinh IN (N'Nam', N'Nữ'))
);

CREATE TABLE HocSinh (
    MaHocSinh VARCHAR(20) PRIMARY KEY,
    TenLop NVARCHAR(20),
    MaBuaAn VARCHAR(20),
    MaTKB VARCHAR(20),
    TenHS NVARCHAR(100),
    NgaySinh DATE NOT NULL,
    GioiTinh NVARCHAR(10) NOT NULL CHECK (GioiTinh IN (N'Nam', N'Nữ')),
    TTSucKhoe NVARCHAR(100)
);

CREATE TABLE QuanHeGiaDinh (
    MaHocSinh VARCHAR(20),
	MaPhuHuynh VARCHAR(20),
    Mqh NVARCHAR(50),
    PRIMARY KEY (MaHocSinh, MaPhuHuynh),
    FOREIGN KEY (MaHocSinh) REFERENCES HocSinh(MaHocSinh),
    FOREIGN KEY (MaPhuHuynh) REFERENCES PhuHuynh(MaPhuHuynh)
);

CREATE TABLE GiaoVien (
    MaGiaoVien VARCHAR(20) PRIMARY KEY,
    TenGV NVARCHAR(100),
    KinhNghiem INT,
    ChuyenMon NVARCHAR(100),
    LopPhuTrach NVARCHAR(20)
);

CREATE TABLE QuanLy (
    MaHocSinh VARCHAR(20),
    MaGiaoVien VARCHAR(20),
    MonDay NVARCHAR(100),
    PRIMARY KEY (MaHocSinh, MaGiaoVien),
    FOREIGN KEY (MaHocSinh) REFERENCES HocSinh(MaHocSinh),
    FOREIGN KEY (MaGiaoVien) REFERENCES GiaoVien(MaGiaoVien)
);


CREATE TABLE LopHoc (
    TenLop NVARCHAR(20) PRIMARY KEY,
    SiSo INT,
    GVCN NVARCHAR(20)
);

CREATE TABLE PhanCongDay (
    MaGiaoVien VARCHAR(20),
    TenLop NVARCHAR(20),
    NoiDungDay NVARCHAR(255),
    HinhThuc NVARCHAR(50),
    PRIMARY KEY (MaGiaoVien, TenLop),
    FOREIGN KEY (MaGiaoVien) REFERENCES GiaoVien(MaGiaoVien)
);

CREATE TABLE ChuongTrinhDay (
    MaChuongTrinh VARCHAR(20) PRIMARY KEY,
    MaGiaoVien VARCHAR(20),
    NoiDungDay NVARCHAR(255),
    PhuongPhap NVARCHAR(255),
    ThoiLuong NVARCHAR(50),
    FOREIGN KEY (MaGiaoVien) REFERENCES GiaoVien(MaGiaoVien)
);

CREATE TABLE MonHoc (
	MaMonHoc VARCHAR(20) PRIMARY KEY,
    TenMH NVARCHAR(50),
    NoiHoc NVARCHAR(100),
    ThoiGianHoc NVARCHAR(50)
);

CREATE TABLE MonPhuTrach (
    MaMonHoc VARCHAR(20),
    MaGiaoVien VARCHAR(20),
    HocKy VARCHAR(10),
    PRIMARY KEY (MaMonHoc, MaGiaoVien),
    FOREIGN KEY (MaMonHoc) REFERENCES MonHoc(MaMonHoc),
    FOREIGN KEY (MaGiaoVien) REFERENCES GiaoVien(MaGiaoVien)
);

CREATE TABLE ChiTietMonHoc (
    MaMonHoc VARCHAR(20),
    TenLop NVARCHAR(20),
    GiaoVienDay NVARCHAR(100),
    PRIMARY KEY (MaMonHoc, TenLop),
    FOREIGN KEY (MaMonHoc) REFERENCES MonHoc(MaMonHoc),
    FOREIGN KEY (TenLop) REFERENCES LopHoc(TenLop)
);

CREATE TABLE KetQua (
    MaHocSinh VARCHAR(20),
    MaMonHoc VARCHAR(20),
    Diem_so FLOAT,
    Ngay_thi DATE,
    PRIMARY KEY (MaHocSinh, MaMonHoc),
    FOREIGN KEY (MaHocSinh) REFERENCES HocSinh(MaHocSinh),
    FOREIGN KEY (MaMonHoc) REFERENCES MonHoc(MaMonHoc)
);

CREATE TABLE HocPhi (
    MaHocPhi VARCHAR(20) PRIMARY KEY,
    MaHocSinh VARCHAR(20),
    SoTien FLOAT,
    HoaDon NVARCHAR(100),
    FOREIGN KEY (MaHocSinh) REFERENCES HocSinh(MaHocSinh),
);

CREATE TABLE ThoiKhoaBieu (
    MaTKB VARCHAR(20) PRIMARY KEY,
    ThoiGian NVARCHAR(50),
    SoBuoiHoc INT
);

CREATE TABLE LichHoc (
    MaTKB VARCHAR(20),
    MaMonHoc VARCHAR(20),
    Thoi_gian NVARCHAR(50),
    PRIMARY KEY (MaTKB, MaMonHoc),
    FOREIGN KEY (MaTKB) REFERENCES ThoiKhoaBieu(MaTKB),
    FOREIGN KEY (MaMonHoc) REFERENCES MonHoc(MaMonHoc)
);

CREATE TABLE NhanVienTruongHoc (
    MaNhanVien VARCHAR(20) PRIMARY KEY,
    CongViec NVARCHAR(100),
    GioiTinh NVARCHAR(10),
    ThoiGianLamViec NVARCHAR(100)
);

CREATE TABLE BuaAn (
    MaBuaAn VARCHAR(20) PRIMARY KEY,
    ThucDon NVARCHAR(100),
    NguyenLieu NVARCHAR(100),
    SoBua INT
);

CREATE TABLE ChuanBiThucAn (
    MaBuaAn VARCHAR(20),
    MaNhanVien VARCHAR(20),
    NgayCungCap DATE,
    SoTien FLOAT,
    PRIMARY KEY (MaBuaAn, MaNhanVien),
    FOREIGN KEY (MaBuaAn) REFERENCES BuaAn(MaBuaAn),
    FOREIGN KEY (MaNhanVien) REFERENCES NhanVienTruongHoc(MaNhanVien)
);

INSERT INTO LopHoc (TenLop, SiSo, GVCN)
VALUES 
(N'Lớp 3A', 20, 'GV01'), (N'Lớp 3B', 22, 'GV02'), (N'Lớp 3C', 25, 'GV03'), (N'Lớp 3D', 23, 'GV04'),
(N'Lớp 4A', 18, 'GV06'), (N'Lớp 4B', 20, 'GV07'), (N'Lớp 4C', 19, 'GV08'), (N'Lớp 4D', 24, 'GV09'),
(N'Lớp 5A', 23, 'GV11'), (N'Lớp 5B', 22, 'GV12'), (N'Lớp 5C', 25, 'GV13'), (N'Lớp 5D', 21, 'GV14');

INSERT INTO GiaoVien (MaGiaoVien, TenGV, KinhNghiem, ChuyenMon, LopPhuTrach)
VALUES
('GV01', N'Lê Huỳnh Nhy', 5, N'Toán', N'Lớp 3A'), ('GV02', N'Trần Mai Anh', 3, N'Tiếng Việt', N'Lớp 3B'),
('GV03', N'Lê Thị Hồng Liễu', 4, N'Thủ công', N'Lớp 3C'), ('GV04', N'Trần Phương Thảo', 6, N'Mỹ Thuật', N'Lớp 3D'),
('GV05', N'Đinh Thị Minh Tâm', 7, N'Âm Nhạc', N'Lớp 4A'), ('GV06', N'Phạm Thu Trang', 3, N'Kể chuyện - Đọc sách', N'Lớp 4B'),
('GV07', N'Trần Vũ Hải Anh', 5, N'Tiếng Anh giao tiếp', N'Lớp 4C'), ('GV08', N'Đỗ Khánh Linh', 2, N'Kỹ năng sống', N'Lớp 4D'),
('GV09', N'Trần Hương Giang', 4, N'Trò chơi dân gian', N'Lớp 5A'), ('GV10', N'Nguyễn Anh Linh', 5, N'Thể dục thể thao', N'Lớp 5B'),
('GV11', N'Mai Quốc Khánh', 5, N'Khoa Học', N'Lớp 5C'),('GV12', N'Ôn Dĩ Phàm', 5, N'Nhảy Múa', N'Lớp 5D');

INSERT INTO HocSinh (MaHocSinh, TenLop, MaBuaAn, MaTKB, TenHS, NgaySinh, GioiTinh, TTSucKhoe) 
VALUES
('HS01', N'Lớp 3A', 'BA01', 'TKB01', N'Trần An Bình', '2021-05-01', N'Nữ', N'Sức khỏe tốt, không dị ứng.'),
('HS02', N'Lớp 3A', 'BA02', 'TKB01', N'Phạm Minh Tuấn', '2021-04-01', N'Nam', N'Thỉnh thoảng bị cảm lạnh.'),
('HS03', N'Lớp 3A', 'BA03', 'TKB01', N'Ngô Thị Mai', '2021-05-01', N'Nữ', N'Sức khỏe ổn định.'),
('HS04', N'Lớp 3A', 'BA04', 'TKB01', N'Đặng Quốc Duy', '2020-11-01', N'Nam', N'Cần điều trị viêm họng.'),
('HS05', N'Lớp 4B', 'BA05', 'TKB02', N'Lương Quỳnh Anh', '2020-06-01', N'Nữ', N'Sức khỏe tốt, thích thể thao.'),
('HS06', N'Lớp 4B', 'BA06', 'TKB02', N'Nguyễn Hải Nam', '2020-04-01', N'Nam', N'Thỉnh thoảng bị ho khan.'),
('HS07', N'Lớp 5B', 'BA07', 'TKB02', N'Cao Thị Lan', '2019-02-01', N'Nữ', N'Không có vấn đề sức khỏe.'),
('HS08', N'Lớp 5B', 'BA08', 'TKB02', N'Hà Quang Huy', '2019-10-01', N'Nam', N'Không dị ứng thực phẩm.'),
('HS09', N'Lớp 4C', 'BA09', 'TKB03', N'Kiều Thị Thanh', '2020-08-01', N'Nữ', N'Sức khỏe tốt, không dị ứng.'),
('HS10', N'Lớp 4C', 'BA10', 'TKB03', N'Lâm Thanh Tùng', '2020-09-01', N'Nam', N'Thỉnh thoảng bị cảm cúm.'),
('HS11', N'Lớp 4C', 'BA11', 'TKB03', N'Nguyễn Hoàng Nam', '2020-10-01', N'Nam', N'Sức khỏe ổn định, không dị ứng.'),
('HS12', N'Lớp 3C', 'BA12', 'TKB03', N'Mai Lan Anh', '2021-07-01', N'Nữ', N'Sức khỏe tốt, thích chơi thể thao.'),
('HS13', N'Lớp 3D', 'BA13', 'TKB04', N'Lê Quang Minh', '2021-01-01', N'Nam', N'Sức khỏe tốt, không dị ứng.'),
('HS14', N'Lớp 3D', 'BA14', 'TKB04', N'Nguyễn Minh Hòa', '2021-03-01', N'Nữ', N'Thỉnh thoảng bị ho.'),
('HS15', N'Lớp 3D', 'BA15', 'TKB04', N'Trần Thị Lan', '2022-01-01', N'Nữ', N'Không có vấn đề sức khỏe.'),
('HS16', N'Lớp 4A', 'BA16', 'TKB05', N'Nguyễn Quang Huy', '2020-04-01', N'Nam', N'Sức khỏe ổn định, thích thể thao.'),
('HS17', N'Lớp 4A', 'BA17', 'TKB05', N'Lê Mai Hoa', '2020-07-01', N'Nữ', N'Sức khỏe tốt, không dị ứng.'),
('HS18', N'Lớp 4A', 'BA18', 'TKB05', N'Phan Văn Quân', '2020-08-01', N'Nam', N'Thỉnh thoảng bị cảm lạnh.'),
('HS19', N'Lớp 4A', 'BA19', 'TKB05', N'Trần Thị Lan', '2021-02-01', N'Nữ', N'Sức khỏe ổn định.'),
('HS20', N'Lớp 4B', 'BA20', 'TKB02', N'Lê Thị Thanh', '2020-05-01', N'Nữ', N'Sức khỏe tốt, không dị ứng.'),
('HS21', N'Lớp 4B', 'BA21', 'TKB01', N'Trần Quốc Duy', '2020-12-01', N'Nam', N'Thỉnh thoảng bị ho khan.'),
('HS22', N'Lớp 4B', 'BA22', 'TKB04', N'Nguyễn Quang Huy', '2020-06-01', N'Nam', N'Sức khỏe tốt, thích thể thao.'),
('HS23', N'Lớp 4B', 'BA23', 'TKB03', N'Phạm Lan Anh', '2020-09-01', N'Nữ', N'Thỉnh thoảng bị cảm cúm.'),
('HS24', N'Lớp 5A', 'BA24', 'TKB02', N'Nguyễn Thị Mai', '2019-08-01', N'Nữ', N'Sức khỏe tốt, thích nghệ thuật.'),
('HS25', N'Lớp 5A', 'BA25', 'TKB03', N'Phan Minh Tuấn', '2019-07-01', N'Nam', N'Sức khỏe tốt, thích thể thao.');


INSERT INTO PhuHuynh (MaPhuHuynh, TenPH, Sdt, GioiTinh)
VALUES 
('PH01', N'Nguyễn Thị Lan', '0912340001', N'Nữ'), ('PH02', N'Trần Văn Minh', '0912340002', N'Nam'),
('PH03', N'Lê Thị Thanh', '0912340003', N'Nữ'), ('PH04', N'Phạm Văn Long', '0912340004', N'Nam'),
('PH05', N'Vũ Thị Mai', '0912340005', N'Nữ'), ('PH06', N'Ngô Văn Bình', '0912340006', N'Nam'),
('PH07', N'Tô Thị Huệ', '0912340007', N'Nữ'), ('PH08', N'Đặng Văn Hùng', '0912340008', N'Nam'),
('PH09', N'Hồ Thị Hạnh', '0912340009', N'Nữ'), ('PH10', N'Lương Văn Hải', '0912340010', N'Nam'),
('PH11', N'Lê Thị Ngọc', '0912340011', N'Nữ'), ('PH12', N'Nguyễn Văn Sơn', '0912340012', N'Nam'),
('PH13', N'Phan Thị Hiền', '0912340013', N'Nữ'), ('PH14', N'Cao Văn Phúc', '0912340014', N'Nam'),
('PH15', N'Đinh Thị Hà', '0912340015', N'Nữ'), ('PH16', N'Hà Văn Dũng', '0912340016', N'Nam'),
('PH17', N'Trịnh Thị Ngân', '0912340017', N'Nữ'), ('PH18', N'Kiều Văn Hòa', '0912340018', N'Nam'),
('PH19', N'Lý Thị Sen', '0912340019', N'Nữ'), ('PH20', N'Lâm Văn Tuấn', '0912340020', N'Nam'),
('PH21', N'Châu Thị Thủy', '0912340021', N'Nữ'), ('PH22', N'Nguyễn Văn Tín', '0912340022', N'Nam'),
('PH23', N'Võ Thị Hương', '0912340023', N'Nữ'), ('PH24', N'Mai Văn Tâm', '0912340024', N'Nam'),
('PH25', N'Đoàn Thị Tuyết', '0912340025', N'Nữ');

INSERT INTO BuaAn (MaBuaAn, ThucDon, NguyenLieu, SoBua)
VALUES
('BA01', N'Cơm thịt kho trứng', N'Gạo, thịt heo, trứng, gia vị', 2),
('BA02', N'Cháo cá hồi', N'Cá hồi, gạo tẻ, hành lá, nước mắm', 2),
('BA03', N'Mì nui xào bò', N'Nui, thịt bò, cà rốt, hành tây', 1),
('BA04', N'Phở bò', N'Bánh phở, thịt bò, hành, rau thơm', 2),
('BA05', N'Bún thịt nướng', N'Bún, thịt nướng, rau sống, mắm', 1),
('BA06', N'Cơm gà xối mỡ', N'Gà, gạo, nước mắm, rau', 2),
('BA07', N'Súp cua trứng', N'Cua, trứng, nấm, bắp ngô', 1),
('BA08', N'Cháo thịt bằm', N'Gạo, thịt heo, hành tím, nước', 2),
('BA09', N'Cơm cá sốt cà', N'Cá, cà chua, hành lá, gạo', 1),
('BA10', N'Mì trứng rau củ', N'Mì, trứng, cà rốt, súp lơ', 2);


INSERT INTO MonHoc (MaMonHoc, TenMH, NoiHoc, ThoiGianHoc)
VALUES
('MH01', N'Toán', N'Phòng học chính', N'Thứ 2 - Sáng'),
('MH02', N'Mỹ Thuật', N'Phòng vẽ', N'Thứ 3 - Sáng'),
('MH03', N'Tiếng Việt', N'Phòng học chính', N'Thứ 4 - Sáng'),
('MH04', N'Thủ công', N'Phòng sáng tạo', N'Thứ 5 - Sáng'),
('MH05', N'Âm Nhạc', N'Phòng âm nhạc', N'Thứ 6 - Sáng'),
('MH06', N'Kể chuyện - Đọc sách', N'Thư viện thiếu nhi', N'Thứ 2 - Chiều'),
('MH07', N'Tiếng Anh giao tiếp', N'Phòng tiếng Anh', N'Thứ 3 - Chiều'),
('MH08', N'Kỹ năng sống', N'Sân trường / Phòng kỹ năng', N'Thứ 4 - Chiều'),
('MH09', N'Thể dục thể thao', N'Sân thể chất', N'Thứ 5 - Chiều'),
('MH10', N'Trò chơi dân gian', N'Sân chơi', N'Thứ 6 - Chiều'),
('MH11', N'Khoa Học', N'Phòng thí nghiệm nhỏ', N'Thứ 7 - Sáng'),
('MH12', N'Nhảy Múa', N'Phòng đa năng', N'Thứ 7 - Chiều');

INSERT INTO ChuongTrinhDay (MaChuongTrinh, MaGiaoVien, NoiDungDay, PhuongPhap, ThoiLuong)
VALUES
('CT01', 'GV01', N'Giới thiệu các con số, phép cộng đơn giản', N'Đố vui, trò chơi toán học', N'30 phút'),
('CT02', 'GV04', N'Vẽ tranh phong cảnh, tô màu sáng tạo', N'Hướng dẫn thực hành, quan sát', N'40 phút'),
('CT03', 'GV02', N'Học bảng chữ cái, tập đánh vần', N'Kể chuyện minh họa, bài hát chữ cái', N'35 phút'),
('CT04', 'GV03', N'Làm đồ chơi từ giấy, gấp hình đơn giản', N'Làm mẫu, hướng dẫn nhóm nhỏ', N'45 phút'),
('CT05', 'GV05', N'Học hát, nhận biết nhạc cụ', N'Nghe nhạc, thực hành hát cùng nhạc', N'30 phút'),
('CT06', 'GV06', N'Kể chuyện cổ tích, đọc truyện ngắn', N'Kể chuyện minh họa bằng tranh', N'35 phút'),
('CT07', 'GV07', N'Học câu chào hỏi cơ bản bằng tiếng Anh', N'Nghe - nhắc lại - diễn vai', N'40 phút'),
('CT08', 'GV08', N'Học cách chào hỏi, giữ gìn vệ sinh', N'Thực hành qua tình huống, trò chơi', N'35 phút'),
('CT09', 'GV10', N'Bài tập vận động cơ bản', N'Thể dục theo nhạc, trò chơi vận động', N'45 phút'),
('CT10', 'GV09', N'Chơi ô ăn quan, bịt mắt bắt dê', N'Thực hành nhóm, chơi thử', N'30 phút'),
('CT11', 'GV11', N'Khám phá khoa học quanh em: nước, đất', N'Thí nghiệm đơn giản, quan sát', N'40 phút'),
('CT12', 'GV12', N'Học các điệu múa đơn giản', N'Làm mẫu, học theo nhóm', N'50 phút');

INSERT INTO ThoiKhoaBieu (MaTKB, ThoiGian, SoBuoiHoc)
VALUES
('TKB01', N'Tuần 1 (01/04 - 05/04)', 10),
('TKB02', N'Tuần 2 (08/04 - 12/04)', 10),
('TKB03', N'Tuần 3 (15/04 - 19/04)', 10),
('TKB04', N'Tuần 4 (22/04 - 26/04)', 10),
('TKB05', N'Tuần 5 (29/04 - 03/05)', 8);

INSERT INTO HocPhi (MaHocPhi, MaHocSinh, SoTien, HoaDon) 
VALUES
('HP01', 'HS01', 1500000, N'Thanh toán tháng 4'),('HP02', 'HS02', 1490000, N'Thanh toán tháng 4'),
('HP03', 'HS03', 1350000, N'Thanh toán tháng 4'),('HP04', 'HS04', 1560000, N'Thanh toán tháng 4'),
('HP05', 'HS05', 1450000, N'Thanh toán tháng 4'),('HP06', 'HS06', 1760000, N'Thanh toán tháng 4'),
('HP07', 'HS07', 1670000, N'Thanh toán tháng 4'),('HP08', 'HS08', 1230000, N'Thanh toán tháng 4'),
('HP09', 'HS09', 1480000, N'Thanh toán tháng 4'),('HP10', 'HS10', 1980000, N'Thanh toán tháng 4');

INSERT INTO HocPhi (MaHocPhi, MaHocSinh, SoTien, HoaDon) 
VALUES
('HP11', 'HS11', 1550000, N'Thanh toán tháng 4'),('HP12', 'HS12', 1420000, N'Thanh toán tháng 4'),
('HP13', 'HS13', 1600000, N'Thanh toán tháng 4'),('HP14', 'HS14', 1500000, N'Thanh toán tháng 4'),
('HP15', 'HS15', 1490000, N'Thanh toán tháng 4'),('HP16', 'HS16', 1570000, N'Thanh toán tháng 4'),
('HP17', 'HS17', 1680000, N'Thanh toán tháng 4'),('HP18', 'HS18', 1380000, N'Thanh toán tháng 4'),
('HP19', 'HS19', 1730000, N'Thanh toán tháng 4'),('HP20', 'HS20', 1510000, N'Thanh toán tháng 4'),
('HP21', 'HS21', 1640000, N'Thanh toán tháng 4'),('HP22', 'HS22', 1550000, N'Thanh toán tháng 4'),
('HP23', 'HS23', 1450000, N'Thanh toán tháng 4'),('HP24', 'HS24', 1690000, N'Thanh toán tháng 4'),
('HP25', 'HS25', 1520000, N'Thanh toán tháng 4');

INSERT INTO NhanVienTruongHoc (MaNhanVien, CongViec, GioiTinh, ThoiGianLamViec)
VALUES
('NV01', N'Nấu ăn', N'Nữ', N'Sáng - Chiều'),
('NV02', N'Quản lý bếp', N'Nữ', N'Sáng'),
('NV03', N'Lau dọn', N'Nữ', N'Sáng - Chiều'),
('NV04', N'Bảo vệ', N'Nam', N'Ca đêm'),
('NV05', N'Y tế học đường', N'Nữ', N'Sáng'),
('NV06', N'Chăm sóc sân chơi', N'Nam', N'Sáng - Chiều'),
('NV07', N'Phục vụ ăn uống', N'Nữ', N'Trưa'),
('NV08', N'Kỹ thuật trường', N'Nam', N'Chiều'),
('NV09', N'Lễ tân', N'Nữ', N'Sáng'),
('NV10', N'Tạp vụ', N'Nữ', N'Sáng - Chiều');

INSERT INTO QuanHeGiaDinh(MaHocSinh, MaPhuHuynh, Mqh)
VALUES 
('HS13', 'PH01', N'Mẹ'),('HS01', 'PH02', N'Bố'),
('HS14', 'PH03', N'Mẹ'),('HS02', 'PH04', N'Bố'),
('HS15', 'PH05', N'Mẹ'),('HS03', 'PH06', N'Bố'),
('HS16', 'PH07', N'Mẹ'),('HS04', 'PH08', N'Bố'),
('HS17', 'PH09', N'Mẹ'),('HS05', 'PH10', N'Bố'),
('HS18', 'PH11', N'Mẹ'),('HS06', 'PH12', N'Bố'),
('HS19', 'PH13', N'Mẹ'),('HS07', 'PH14', N'Bố'),
('HS20', 'PH15', N'Mẹ'),('HS08', 'PH16', N'Bố'),
('HS21', 'PH17', N'Mẹ'),('HS09', 'PH18', N'Bố'),
('HS22', 'PH19', N'Mẹ'),('HS10', 'PH20', N'Bố'),
('HS23', 'PH21', N'Mẹ'),('HS11', 'PH22', N'Bố'),
('HS24', 'PH23', N'Mẹ'),('HS12', 'PH24', N'Bố'),
('HS25', 'PH25', N'Mẹ');

INSERT INTO QuanLy(MaHocSinh, MaGiaoVien, MonDay)
VALUES
('HS01', 'GV01', N'Toán'),('HS02', 'GV01', N'Toán'),
('HS03', 'GV03', N'Thủ công'),('HS04', 'GV04', N'Mỹ Thuật'),
('HS05', 'GV05', N'Âm Nhạc'),('HS06', 'GV06', N'Kể chuyện - Đọc sách'),
('HS07', 'GV07', N'Tiếng Anh giao tiếp'),('HS08', 'GV08', N'Kỹ năng sống'),
('HS09', 'GV09', N'Trò chơi dân gian'),('HS10', 'GV11', N'Khoa Học'),
('HS11', 'GV10', N'Thể dục thể thao'),('HS12', 'GV12', N'Nhảy Múa'),
('HS13', 'GV01', N'Toán'),('HS14', 'GV02', N'Tiếng Việt'),
('HS15', 'GV02', N'Tiếng Việt'),('HS16', 'GV03', N'Thủ công'),
('HS17', 'GV04', N'Mỹ Thuật'),('HS18', 'GV05', N'Âm Nhạc'),
('HS19', 'GV06', N'Kể chuyện - Đọc sách'),('HS20', 'GV07', N'Tiếng Anh giao tiếp'),
('HS21', 'GV08', N'Kỹ năng sống'),('HS22', 'GV09', N'Trò chơi dân gian'),
('HS23', 'GV10', N'Thể dục thể thao'),('HS24', 'GV11', N'Khoa Học'),
('HS25', 'GV12', N'Nhảy Múa');

INSERT INTO PhanCongDay (MaGiaoVien, TenLop, NoiDungDay, HinhThuc)
VALUES 
('GV01', N'Lớp 3A', N'Dạy môn Toán cơ bản', N'Trực tiếp'),
('GV02', N'Lớp 1B', N'Dạy tiếng Việt vỡ lòng', N'Trực tiếp'),
('GV03', N'Lớp 1C', N'Hướng dẫn thủ công', N'Trực tiếp'),
('GV04', N'Lớp 1D', N'Dạy vẽ và tô màu', N'Trực tiếp'),
('GV05', N'Lớp 4A', N'Dạy hát và nhận biết nhạc cụ', N'Kết hợp'),
('GV06', N'Lớp 4B', N'Kể chuyện và đọc sách', N'Trực tiếp'),
('GV07', N'Lớp 4C', N'Giao tiếp tiếng Anh cơ bản', N'Trực tiếp'),
('GV08', N'Lớp 4D', N'Kỹ năng sống cơ bản', N'Trò chơi - Tình huống'),
('GV09', N'Lớp 5A', N'Trò chơi dân gian Việt Nam', N'Thực hành nhóm'),
('GV10', N'Lớp 5B', N'Thể dục thể thao', N'Hoạt động ngoài trời'),
('GV11', N'Lớp 5C', N'Tìm hiểu khoa học tự nhiên', N'Thực nghiệm'),
('GV12', N'Lớp 5D', N'Học nhảy múa cơ bản', N'Học theo nhóm');

INSERT INTO MonPhuTrach (MaMonHoc, MaGiaoVien, HocKy)
VALUES 
('MH01', 'GV01', 'HK1'),('MH02', 'GV02', 'HK1'),
('MH03', 'GV03', 'HK1'),('MH04', 'GV04', 'HK2'),
('MH05', 'GV05', 'HK2'),('MH06', 'GV06', 'HK1'),
('MH07', 'GV07', 'HK2'),('MH08', 'GV08', 'HK1'),
('MH09', 'GV09', 'HK2'),('MH10', 'GV10', 'HK1'),
('MH01', 'GV11', 'HK2'),('MH02', 'GV12', 'HK2'); 


INSERT INTO LichHoc(MaTKB, MaMonHoc)
VALUES
('TKB01', 'MH01'), ('TKB01', 'MH02'),
('TKB02', 'MH03'), ('TKB02', 'MH04'),
('TKB03', 'MH05'), ('TKB03', 'MH06'),
('TKB04', 'MH07'), ('TKB04', 'MH08'),
('TKB05', 'MH09'), ('TKB05', 'MH10');



INSERT INTO ChiTietMonHoc(MaMonHoc, TenLop, GiaoVienDay)
VALUES
('MH01', N'Lớp 3B', N'Lê Thị Hồng Liễu'), ('MH02', N'Lớp 3A', N'Lê Huỳnh Nhy'), 
('MH03', N'Lớp 4B', N'Nguyễn Anh Linh'), ('MH04', N'Lớp 3D', N'Trần Vũ Hải Anh'), 
('MH05', N'Lớp 5C', N'Đỗ Khánh Linh'), ('MH06', N'Lớp 3C', N'Đinh Thị Minh Tâm'), 
('MH07', N'Lớp 5A', N'Trần Mai Anh'), ('MH08', N'Lớp 4A', N'Phạm Thu Trang'), 
('MH09', N'Lớp 4C', N'Trần Phương Thảo'), ('MH10', N'Lớp 5B', N'Mai Quốc Khánh'), 
('MH11', N'Lớp 5D', N'Trần Hương Giang'), ('MH12', N'Lớp 4D', N'Ôn Dĩ Phàm');

INSERT INTO KetQua (MaHocSinh, MaMonHoc, Diem_so, Ngay_thi) 
VALUES
('HS01', 'MH01', 8.5, '2025-03-10'),('HS01', 'MH02', 7.0, '2025-03-12'),
('HS01', 'MH03', 9.0, '2025-03-14'),('HS01', 'MH05', 8.2, '2025-03-16'),

('HS02', 'MH01', 7.5, '2025-03-10'),('HS02', 'MH04', 8.0, '2025-03-13'),
('HS02', 'MH06', 7.2, '2025-03-15'),('HS02', 'MH07', 9.1, '2025-03-17'),

('HS03', 'MH02', 6.8, '2025-03-12'),('HS03', 'MH03', 8.7, '2025-03-14'),
('HS03', 'MH04', 7.9, '2025-03-16'),('HS03', 'MH10', 9.0, '2025-03-21'),

('HS04', 'MH05', 8.5, '2025-03-16'),('HS04', 'MH06', 7.7, '2025-03-17'),
('HS04', 'MH08', 6.5, '2025-03-19'),('HS04', 'MH12', 8.8, '2025-03-22'),

('HS05', 'MH01', 9.0, '2025-03-10'),('HS05', 'MH03', 8.4, '2025-03-14'),
('HS05', 'MH05', 7.9, '2025-03-16'),('HS05', 'MH07', 6.7, '2025-03-18'),

('HS06', 'MH02', 8.8, '2025-03-12'),('HS06', 'MH04', 7.6, '2025-03-13'),
('HS06', 'MH06', 6.9, '2025-03-15'),('HS06', 'MH08', 7.4, '2025-03-17'),

('HS07', 'MH01', 7.2, '2025-03-10'),('HS07', 'MH04', 8.5, '2025-03-13'),
('HS07', 'MH05', 9.1, '2025-03-16'),('HS07', 'MH06', 7.0, '2025-03-17'),

('HS08', 'MH03', 8.0, '2025-03-14'),('HS08', 'MH07', 6.5, '2025-03-18'),
('HS08', 'MH08', 8.6, '2025-03-19'),('HS08', 'MH12', 9.0, '2025-03-22'),

('HS09', 'MH02', 7.3, '2025-03-12'),('HS09', 'MH05', 7.9, '2025-03-16'),
('HS09', 'MH09', 8.4, '2025-03-20'),('HS09', 'MH11', 6.8, '2025-03-23'),

('HS10', 'MH01', 6.5, '2025-03-10'),('HS10', 'MH06', 7.7, '2025-03-15'),
('HS10', 'MH08', 9.2, '2025-03-19'),('HS10', 'MH10', 8.0, '2025-03-21'),

('HS11', 'MH04', 8.4, '2025-03-13'),('HS11', 'MH07', 7.6, '2025-03-17'),
('HS11', 'MH11', 6.9, '2025-03-23'),

('HS12', 'MH03', 8.9, '2025-03-14'),('HS12', 'MH05', 7.8, '2025-03-16'),
('HS12', 'MH09', 8.1, '2025-03-20'),('HS12', 'MH12', 9.3, '2025-03-22'),

('HS13', 'MH02', 7.7, '2025-03-12'),('HS13', 'MH04', 8.0, '2025-03-13'),
('HS13', 'MH10', 7.3, '2025-03-21'),

('HS14', 'MH01', 6.9, '2025-03-10'),('HS14', 'MH06', 8.4, '2025-03-15'),
('HS14', 'MH11', 7.0, '2025-03-23'),

('HS15', 'MH03', 8.6, '2025-03-14'),('HS15', 'MH07', 7.2, '2025-03-18'),
('HS15', 'MH09', 8.5, '2025-03-20'),

('HS16', 'MH02', 9.1, '2025-03-12'),('HS16', 'MH05', 8.0, '2025-03-16'),
('HS16', 'MH12', 7.6, '2025-03-22'),

('HS17', 'MH04', 7.8, '2025-03-13'),('HS17', 'MH06', 8.2, '2025-03-15'),
('HS17', 'MH08', 6.7, '2025-03-19'),

('HS18', 'MH01', 7.5, '2025-03-10'),('HS18', 'MH07', 8.3, '2025-03-18'),
('HS18', 'MH09', 9.0, '2025-03-20'),

('HS19', 'MH03', 6.9, '2025-03-14'),('HS19', 'MH10', 7.5, '2025-03-21'),
('HS19', 'MH11', 7.1, '2025-03-23'),

('HS20', 'MH02', 8.7, '2025-03-12'),('HS20', 'MH06', 7.6, '2025-03-15'),
('HS20', 'MH12', 9.2, '2025-03-22'),

('HS21', 'MH01', 8.0, '2025-03-10'),('HS21', 'MH05', 7.4, '2025-03-16'),
('HS21', 'MH08', 6.9, '2025-03-19'),

('HS22', 'MH04', 8.9, '2025-03-13'),('HS22', 'MH07', 7.0, '2025-03-17'),
('HS22', 'MH09', 8.3, '2025-03-20'),

('HS23', 'MH02', 7.6, '2025-03-12'),('HS23', 'MH06', 8.5, '2025-03-15'),
('HS23', 'MH10', 8.9, '2025-03-21'),

('HS24', 'MH01', 6.8, '2025-03-10'),('HS24', 'MH03', 7.2, '2025-03-14'),
('HS24', 'MH08', 9.1, '2025-03-19'),

('HS25', 'MH05', 8.0, '2025-03-16'),('HS25', 'MH09', 7.7, '2025-03-20'),
('HS25', 'MH11', 8.4, '2025-03-23');

INSERT INTO ChuanBiThucAn(MaBuaAn, MaNhanVien, NgayCungCap, SoTien)
VALUES
('BA01', 'NV01', '2025-03-01', 120000),
('BA02', 'NV02', '2025-03-02', 135000),
('BA03', 'NV03', '2025-03-03', 125000),
('BA04', 'NV04', '2025-03-04', 140000),
('BA05', 'NV05', '2025-03-05', 130000),
('BA06', 'NV06', '2025-03-06', 145000),
('BA07', 'NV07', '2025-03-07', 150000),
('BA08', 'NV08', '2025-03-08', 138000),
('BA09', 'NV09', '2025-03-09', 142000),
('BA10', 'NV10', '2025-03-10', 148000);

