﻿USE QuanLyTrgMamNon;

-- 1. Đưa ra danh sách trẻ thuộc lớp 5A.
SELECT MaHocSinh, TenHS, TenLop 
FROM HocSinh
WHERE TenLop = N'Lớp 5A';

-- 2. Liệt kê các lớp có hơn hoặc bằng 23 học sinh.
SELECT TenLop, SiSo AS SoLuongHocSinh 
FROM LopHoc
WHERE SiSo >= 23;

-- 3. Cho biết học sinh có số tiền lớn hơn 1500000
SELECT MaHocSinh, SoTien 
FROM HocPhi
WHERE SoTien > 1500000;

-- 4. Cho biết tên giáo viên và lớp phụ trách của từng giáo viên, chỉ lấy những giáo viên có kinh nghiệm lớn hơn 5 năm.
SELECT TenGV, KinhNghiem, LopPhuTrach 
FROM GiaoVien
WHERE KinhNghiem > 5;

-- 5. Cho biết tên phụ huynh của trẻ có mã học sinh là ‘HS16’
SELECT ph.MaPhuHuynh, ph.TenPH 
FROM PhuHuynh ph
JOIN QuanHeGiaDinh qhgd ON ph.MaPhuHuynh = qhgd.MaPhuHuynh
JOIN HocSinh hs ON qhgd.MaHocSinh = hs.MaHocSinh
WHERE hs.MaHocSinh = 'HS16';

-- 6. Cho biết mã chương trình giảng dạy của giáo viên có tên là ‘Trần Vũ Hải Anh’
SELECT gd.MaChuongTrinh, gv.TenGV 
FROM ChuongTrinhDay gd
JOIN GiaoVien gv ON gd.MaGiaoVien = gv.MaGiaoVien
WHERE gv.TenGV = N'Trần Vũ Hải Anh';

-- 7. Cho biết học sinh học các môn do giáo viên có mã giáo viên ‘GV07’ giảng dạy
SELECT kq.MaHocSinh 
FROM KetQua kq
JOIN MonHoc mh ON kq.MaMonHoc = mh.MaMonHoc
JOIN MonPhuTrach mpt ON mh.MaMonHoc = mpt.MaMonHoc
JOIN GiaoVien gv ON mpt.MaGiaoVien = gv.MaGiaoVien
WHERE gv.MaGiaoVien = 'GV07';

-- 8. Đếm số lượng chương trình dạy có thời lượng 40 phút
SELECT ThoiLuong, COUNT(MaChuongTrinh) AS SoLuongChuongTrinhDay 
FROM ChuongTrinhDay
WHERE ThoiLuong = N'40 phút'
GROUP BY ThoiLuong;

-- 9. Đếm số lượng học sinh áp dụng thời khóa biểu TKB02
SELECT MaTKB, COUNT(MaHocSinh) AS SoLuongHocSinh 
FROM HocSinh
WHERE MaTKB = 'TKB02'
GROUP BY MaTKB;

-- 10. Cho biết số lượng bữa ăn có tổng tiền lớn hơn 140000 và số bữa là 2
SELECT CBTA.MaBuaAn, SUM(SoTien) AS TongTien 
FROM ChuanBiThucAn CBTA
JOIN BuaAn BA ON CBTA.MaBuaAn = BA.MaBuaAn
WHERE BA.SoBua = 2 
GROUP BY CBTA.MaBuaAn
HAVING SUM(SoTien) > 140000;

-- 11. Cho biết các lớp có hơn hoặc bằng 2 bé gái và có sĩ số học sinh trên 15
SELECT l.TenLop, COUNT(hs.MaHocSinh) AS SoHocSinhNu 
FROM LopHoc l
JOIN HocSinh hs ON l.TenLop = hs.TenLop
WHERE hs.GioiTinh = N'Nữ' AND l.SiSo > 15
GROUP BY l.TenLop
HAVING COUNT(hs.MaHocSinh) >= 2;

-- 12. Cho biết bữa ăn có số tiền trung bình lớn hơn 128000 sau ngày 1/3/2025
SELECT MaBuaAn, AVG(SoTien) AS SoTienTrungBinh 
FROM ChuanBiThucAn
WHERE NgayCungCap > '2025-03-01'
GROUP BY MaBuaAn
HAVING AVG(SoTien) > 128000;

-- 13. Số học sinh nữ trong từng lớp (>=2), sắp xếp giảm dần theo số lượng
SELECT lop.TenLop, COUNT(hs.MaHocSinh) AS SoLuongNu 
FROM LopHoc lop
JOIN HocSinh hs ON lop.TenLop = hs.TenLop
WHERE hs.GioiTinh = N'Nữ'
GROUP BY lop.TenLop
HAVING COUNT(hs.MaHocSinh) >= 2
ORDER BY SoLuongNu DESC;

-- 14. Điểm trung bình từng môn (ngày thi > 01/03/2025, điểm TB > 7), sắp xếp giảm dần
SELECT MaMonHoc, AVG(Diem_so) AS DiemTrungBinh 
FROM KetQua
WHERE Ngay_thi > '2025-03-01'
GROUP BY MaMonHoc
HAVING AVG(Diem_so) > 7
ORDER BY DiemTrungBinh DESC;

-- 15. Học sinh nữ có học phí < học phí trung bình của nữ
SELECT HocPhi.MaHocSinh, AVG(HocPhi.SoTien) AS SoTienTrungBinh
FROM HocPhi
JOIN HocSinh ON HocPhi.MaHocSinh = HocSinh.MaHocSinh
WHERE HocSinh.GioiTinh = N'Nữ'
GROUP BY HocPhi.MaHocSinh
HAVING AVG(HocPhi.SoTien) < (
    SELECT AVG(SoTien)
    FROM HocPhi
    JOIN HocSinh ON HocPhi.MaHocSinh = HocSinh.MaHocSinh
    WHERE HocSinh.GioiTinh = N'Nữ'
);

-- 16. Lớp có sĩ số bằng với lớp đông học sinh nhất
SELECT TenLop
FROM HocSinh
GROUP BY TenLop
HAVING COUNT(*) = (
    SELECT MAX(SiSo)
    FROM (
        SELECT COUNT(*) AS SiSo
        FROM HocSinh
        GROUP BY TenLop
    ) AS TongSiSo
);

-- 17. Học sinh trùng mã bữa ăn với Trần Quốc Duy
SELECT * 
FROM HocSinh
WHERE MaBuaAn = (
    SELECT MaBuaAn 
    FROM HocSinh
    WHERE TenHS = N'Trần Quốc Duy'
) AND TenHS <> N'Trần Quốc Duy';

-- 18. Thêm bé mới vào bảng HọcSinh nếu chưa tồn tại
INSERT INTO HocSinh (MaHocSinh, TenLop, MaBuaAn, MaTKB, TenHS, NgaySinh, GioiTinh, TTSucKhoe)
SELECT 'HS29', N'Lớp 3A', 'BA29', 'TKB29', N'Vũ Việt Tân', '2021-11-29', N'Nam', N'Sức khỏe tốt, không dị ứng.'
WHERE NOT EXISTS (
    SELECT 1 
    FROM HocSinh 
    WHERE MaHocSinh = '231230897'
);

-- 19. Thêm bữa ăn mới vào bảng BuaAn
INSERT INTO BuaAn (MaBuaAn, ThucDon, NguyenLieu, SoBua)
SELECT 'BA113', N'Cơm thịt kho trứng', N'Gạo, thịt heo, trứng, gia vị', 2
WHERE NOT EXISTS (
    SELECT 1 
    FROM BuaAn 
    WHERE MaBuaAn = 'BA113'
);

-- 20. Cập nhật trạng thái đủ điều kiện lên lớp
ALTER TABLE HocSinh ADD TrangThai NVARCHAR(50);

UPDATE HocSinh 
SET TrangThai = N'Đủ điều kiện lên lớp' 
WHERE DATEDIFF(YEAR, NgaySinh, GETDATE()) > 5;

-- 21. Cập nhật số điện thoại phụ huynh PH21
UPDATE PhuHuynh
SET Sdt = '0355880362' 
WHERE MaPhuHuynh = 'PH21';

-- 22. Cập nhật học phí tăng thêm 100.000 cho học sinh có học phí dưới 1.500.000
UPDATE HocPhi
SET SoTien = SoTien + 100000
WHERE SoTien < 1500000;

-- 23. Xóa suất ăn chưa được học sinh nào sử dụng
DELETE FROM BuaAn
WHERE MaBuaAn NOT IN (
    SELECT DISTINCT MaBuaAn 
    FROM HocSinh
);

-- 24. Xóa lớp học không có học sinh nào theo học
DELETE FROM LopHoc
WHERE TenLop NOT IN (
    SELECT DISTINCT TenLop 
    FROM HocSinh
);

-- 25. Danh sách bé lớp "Lớp 3A" sinh trong tháng hiện tại
SELECT * 
FROM HocSinh 
WHERE TenLop = N'Lớp 3A'
AND MONTH(NgaySinh) = MONTH(GETDATE());

-- 26. Thống kê số học sinh nam/nữ trong từng lớp
SELECT TenLop, GioiTinh, COUNT(*) AS SoLuong
FROM HocSinh
GROUP BY TenLop, GioiTinh;

-- 27. Liệt kê giáo viên chủ nhiệm của các lớp 4
SELECT * 
FROM GiaoVien 
WHERE LopPhuTrach LIKE N'Lớp 4%';

-- 28. Danh sách các bé có tình trạng sức khỏe "Không dị ứng"
SELECT * 
FROM HocSinh
WHERE TTSucKhoe LIKE N'%Không dị ứng%';

-- 29. Tính phần trăm học sinh đúng độ tuổi theo từng khối lớp
SELECT TenLop,
       (COUNT(CASE 
                WHEN DATEDIFF(YEAR, NgaySinh, GETDATE()) BETWEEN 6 AND 7 
                THEN 1 
            END) * 100.0) / COUNT(*) AS PhanTramDungDoTuoi
FROM HocSinh
GROUP BY TenLop;
